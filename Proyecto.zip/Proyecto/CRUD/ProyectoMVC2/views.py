from django.shortcuts import render

from .models import Vacas
from .models import Queso
from django.http import HttpResponse
from django.conf import settings
from io import BytesIO
from reportlab.pdfgen import canvas
from django.views.generic import View
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from .models import Produccion
from .models import Ordenador
from .models import Becerro
# Create your views here.

def index(request):
 	return HttpResponse("Hello, world. You're at the polls index.")





#def hello(request):
    # Create the HttpResponse object with the appropriate PDF headers.
    #response = HttpResponse(content_type='application/pdf')
    #response['Content-Disposition'] = 'attachment; filename=hello.pdf'

	
    # Create the PDF object, using the response object as its "file."
    #p = canvas.Canvas(response)
 
    # Draw things on the PDF. Here's where the PDF generation happens.
    # See the ReportLab documentation for the full list of functionality.
    #p.drawString(100, 100, "Hello world.")
 
     #Close the PDF object cleanly, and we're done.
    #p.showPage()
    #p.save()
    #return response




def crear1(persona2):
	per2=persona2

	if per2 >1 and per2 < 30:
		return  3
	elif per2 > 31 and per2 < 50:
		return  4
	else:
		return 5



def quesosRe(request):
	
	lista = Queso.objects.all()
	contexto = {'quesos': lista}
	return render(request, 'reporte.html', contexto)


def vacasRe(request):
	
	lista1 = Vacas.objects.all()
	contexto = {'vacas': lista1}
	return render(request, 'reporte_vacas.html', contexto)





class reportePersonasPDF(View):

	def cabecera(self,pdf):
		pdf.setFont("Helvetica", 16)
		pdf.drawString(180,790, u"AGROPECUARIA MACAREITO")
		pdf.setFont("Helvetica", 14)
		pdf.drawString(220,770, u"REPORTE DE QUESOS")



	def tabla(self,pdf,y):
		
		encabezados= ('QUESO 1', 'QUESO 2','QUESO 3', 'QUESO 4', 'QUESO 5', 'FECHA', 'LECHE','EQ')
		detalles=[]




		for persona1 in Queso.objects.all():
			m = crear1(persona1.produccion.lecheu)
			
			if m == 5:
				detalles= [(persona1.Queso1, persona1.Queso2, persona1.Queso3, persona1.Queso4, persona1.Queso5, persona1.FechaE, persona1.produccion.lecheu, crear1(persona1.produccion.lecheu) )]


		detalle_orden= Table([encabezados] + detalles, colWidths=[2.3 * cm, 2.3* cm,2.3 * cm, 2.3 * cm])

		detalle_orden.setStyle(TableStyle(
			[
			('ALIGN',(0,0),(3,0),'CENTER'),
			('GRID', (0, 0), (-1, -1), 1, colors.black),
			('FONTSIZE', (0, 0), (-1, -1), 10),
			]
			))
		detalle_orden.wrapOn(pdf, 800, 600)
		detalle_orden.drawOn(pdf, 60,y)
			
				



	def get(self, request, *args, **kwargs):
			response = HttpResponse(content_type='application/pdf')
			buffer = BytesIO()
			pdf = canvas.Canvas(buffer)
			pdf = canvas.Canvas(buffer)
			self.cabecera(pdf)
			y = 600
			self.tabla(pdf, y)
			pdf.showPage()
			pdf.save()
			pdf = buffer.getvalue()
			buffer.close()
			response.write(pdf)
			return response


