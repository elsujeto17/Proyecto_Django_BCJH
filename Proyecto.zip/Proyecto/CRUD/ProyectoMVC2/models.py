from django.db import models
from multiselectfield import MultiSelectField
from django import forms

# Create your models here.

class Vacas(models.Model):
	
	nombre = models.CharField("Nombre",max_length = 20)
	litro = models.IntegerField("Litros")
	numeracion = models.IntegerField()
	opciones = [
		('Vendida','Vendida'),
		('Fallecio','Fallecio'),
		('En Finca','En Finca'),
		
		


		]
	estado =MultiSelectField( choices = opciones)
	



	
		

	def __str__(self):
		return self.nombre



class Becerro(models.Model):
	
	fechaN = models.DateField( "Fecha De Nacimiento",auto_now=False, auto_now_add=False)
	Madre = models.ForeignKey(Vacas, on_delete=models.CASCADE)


	
class Ordenador(models.Model):
	
	nombreA = models.CharField("Nombre del Ordeñador",max_length = 15)
	apellido = models.CharField("Apellido del Ordeñador",max_length = 20)
	edad = models.IntegerField("Edad del Ordeñador")
	cedula = models.CharField("Cedula",max_length = 10)

	def __str__(self):
		return self.nombreA + " " + self.apellido


class Producto(models.Model):

	nombreP = models.CharField("Nombre del Producto",max_length=15)

	def __str__(self):
		return self.nombreP



class Compradores(models.Model):

	nombreCom = models.CharField("Nombre del Comprador",max_length = 20)
	factura = models.IntegerField()
	fechaCompra = models.DateField()
	producto = models.ForeignKey(Producto, on_delete=models.CASCADE)

	def __str__(self):
		return self.nombreCom






	
	


class Produccion(models.Model):
	
	
	fechaOrdeno = models.DateField("Fecha de Ordeño", auto_now=False, auto_now_add=False)
	litrosOr = models.DecimalField("Litros Ordeñados",max_digits=5, decimal_places=2)
	
	lecheu = models.DecimalField("Leche Utilizada",max_digits=5, decimal_places=2)


	

	



	def quesos_Realizados(self):
		if self.lecheu > 1 and self.lecheu <= 30:
			return "Tres Quesos"
		elif self.lecheu >= 31 and self.lecheu <= 50:
			return "Cuatro Quesos"
		else:
			return "Cinco Quesos"

	def leche_Restante(self):

		return self.litrosOr - self.lecheu


	def calificacion_produccion(self):

		if self.litrosOr >= 50 and self.litrosOr <=100 and self.quesos_Realizados() == "Cinco Quesos":
			return "Mala Produccion"
		elif self.litrosOr >= 101 and self.litrosOr <=145:
			return "Produccion Regular"
		else :
			return "Buena Produccion"
		












class Queso(models.Model):
	
	Queso1 = models.DecimalField('Peso del Queso',max_digits=4, decimal_places=2)
	
	produccion = models.ForeignKey(Produccion, on_delete=models.CASCADE)


