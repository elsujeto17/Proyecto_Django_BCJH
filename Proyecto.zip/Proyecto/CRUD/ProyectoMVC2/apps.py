from django.apps import AppConfig


class Proyectomvc2Config(AppConfig):
    name = 'ProyectoMVC2'
