from django.urls import path

from . import views

urlpatterns = [

	path('quesos/', views.quesosRe, name='quesos'),
	path('vacas/', views.vacasRe, name='vacas'),
	#path('^reporte_personas_pdf/$', views.reportePersonasPDF.as_view(), name='reporte_personas_pdf'),
	#path('hello/', views.hello, name='hello'),
	#path('', views.index, name='index'),


]