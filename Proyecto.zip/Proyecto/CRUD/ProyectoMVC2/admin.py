from django.contrib import admin
from .models import *

# Register your models here.

class ProduccionA(admin.ModelAdmin):
	list_display = ('id','ordenador', 'litrosOr','fechaOrdeno')
	list_filter = ('fechaOrdeno','litrosOr')
	

class BecerroA(admin.ModelAdmin):
	list_display = ('id','Madre','fechaN')


class VacasB(admin.ModelAdmin):

	search_fields = ('nombre',)
	list_display = ('nombre','litro','numeracion','estado')
	
	change_list_template = 'graficoVacas.html'



class QuesoB(admin.StackedInline):
	model=Queso
	extra=1


class CompradoresList(admin.ModelAdmin):
	list_display=('nombreCom','fechaCompra','producto')
	search_fields = ('fechaCompra','nombreCom')
	list_filter = ('fechaCompra','producto',)



class ProduccionB(admin.ModelAdmin):
	fieldsets = [
	(None,  {'fields':['fechaOrdeno']}),
	('Información De Ordeño',  {'fields':['litrosOr','lecheu']}),              
	
	]
	inlines = [QuesoB]

	list_display=('id','fechaOrdeno','litrosOr','lecheu',Produccion.quesos_Realizados,Produccion.leche_Restante,Produccion.calificacion_produccion)
	list_filter = ('fechaOrdeno','litrosOr')

	change_list_template = 'grafico.html'




class OrdenadorList(admin.ModelAdmin):
	list_display = ('nombreA','apellido','cedula')



admin.site.register(Vacas, VacasB)
admin.site.register(Becerro, BecerroA)
admin.site.register(Ordenador,OrdenadorList)
admin.site.register(Produccion, ProduccionB)
admin.site.register(Producto)
admin.site.register(Compradores,CompradoresList)




